package Apple_iStore_Controller;

import static Apple_iStore_Controller.db_Connection.connection;
import Apple_iStore_Model.product;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class product_Controller {

    //method for adding data
    public void add(product pro) {
        try {

            String query = "INSERT INTO product (p_id ,	p_name,  p_price , p_qty , p_category) VALUES (?,?,?,?,?)";
            PreparedStatement add = connection().prepareStatement(query);
            int id = 0;
            add.setInt(1, id);
            add.setString(2, pro.getName());
            add.setString(3, pro.getPrice());
            add.setString(4, pro.getQty());
            add.setString(5, pro.getCat());

            add.executeUpdate();
            JOptionPane.showMessageDialog(null, "Recored has been added");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
    }

    public List<product> loadData() {

        List<product> list = new ArrayList<product>();
        try {
            String query = "SELECT * FROM product";
            PreparedStatement ps = connection().prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int Id = rs.getInt("p_id");
                String Name = rs.getString("p_name");
                String Price = rs.getString("p_price");
                String Qty = rs.getString("p_qty");
                String Cat = rs.getString("p_category");

                product p1 = new product(Id, Name, Price, Qty, Cat);
                list.add(p1);
            }
        } catch (Exception e) {
            JOptionPane.showInternalMessageDialog(null, e);
        }
        return list;
    }

    //method for load data to text fields
    public product returnAllDataToTextFields(int id) {
        product pr = null;
        try {
            String query = "SELECT * FROM product WHERE p_id = " + id;
            PreparedStatement ps = db_Connection.connection().prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int Ids = rs.getInt("p_id");
                String Name = rs.getString("p_name");
                String Price = rs.getString("p_price");
                Integer.parseInt(Price);
                String Qty = rs.getString("p_qty");
                Integer.parseInt(Qty);
                String cat = rs.getString("p_category");

                pr = new product(Ids, Name, Price, Qty, cat);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
        return pr;
    }

    //delete method
    public void deleteData(int id) {
        try {
            String query = "delete from product WHERE p_id = ?";
            PreparedStatement ps = db_Connection.connection().prepareStatement(query);
            ps.setInt(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "record has been deleted");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
    }

    //method for update 
    public void updateData(product pro) {

        try {
            String query = "UPDATE product SET p_name = ? , p_price = ? , p_qty = ? , p_category = ? WHERE p_id = ?";
            PreparedStatement ps = db_Connection.connection().prepareStatement(query);

            ps.setString(1, pro.getName());
            ps.setString(2, pro.getPrice());
            ps.setString(3, pro.getQty());
            ps.setString(4, pro.getCat());
            ps.setInt(5, pro.getId());

            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "record has been update");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "" + e);
        }
    }

}
