
package Apple_iStore_Model;


public class product {
    
    private int id;
    private String name;
    private String price;
    private String qty;
    private String cat;

    public product(int id, String name, String price, String qty, String cat) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.qty = qty;
        this.cat = cat;
    }

   
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getCat() {
        return cat;
    }

    public void setCat(String cat) {
        this.cat = cat;
    }
    
    
    
    
}
