document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('google-login').addEventListener('click', () => {
        // Redirect to Google OAuth login
        window.location.href = 'https://accounts.google.com/signin';
    });

    document.getElementById('facebook-login').addEventListener('click', () => {
        // Redirect to Facebook OAuth login
        window.location.href = 'https://www.facebook.com/login';
    });

    document.getElementById('google-signup').addEventListener('click', () => {
        // Redirect to Google OAuth signup
        window.location.href = 'https://accounts.google.com/signin';
    });

    document.getElementById('facebook-signup').addEventListener('click', () => {
        // Redirect to Facebook OAuth signup
        window.location.href = 'https://www.facebook.com/login';
    });

    // Handle form submissions (for demo purposes, logs to console)
    document.getElementById('loginForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        console.log(`Login - Email: ${email}, Password: ${password}`);
        alert('Login form submitted');
    });

    document.getElementById('signupForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        console.log(`Sign Up - Name: ${name}, Email: ${email}, Password: ${password}`);
        alert('Sign up form submitted');
    });
});
